/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registrazioni;

import DatiPrelevatiDatabase.Clienti;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Esegue il Login Del cliente prelevando i dati dal database i dati provengono
 * da Utente.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "LoginCliente", urlPatterns = {"/LoginCliente"})
public class LoginCliente extends HttpServlet {

    private Connection con;
    private PreparedStatement prs;
    private Clienti clienti;

    @Override
    public void init() throws ServletException {

        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(LoginCliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        if (con != null) {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(LoginCliente.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        boolean esisteValoreInDatabase = false;
        String nome = null, cognome = null, indirizzoPagina = null;
        int idCliente = 0;

        String sql = "SELECT idcliente, nome, cognome from CLIENTI where username = (?) and password = (?)";

        try {
            if (username == "" && password == "") {
                throw new NullPointerException();
            }

            prs = con.prepareStatement(sql);
            prs.setString(1, username);
            prs.setString(2, password);
            ResultSet rs = prs.executeQuery();

            while (rs.next()) {
                idCliente = rs.getInt("idcliente");
                nome = rs.getString("nome");
                cognome = rs.getString("cognome");
                
                clienti = new Clienti(idCliente, nome, cognome, null, null, null);
                
                esisteValoreInDatabase = true;
            }
        } catch (SQLException | NullPointerException ex) {
            Logger.getLogger(LoginCliente.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (esisteValoreInDatabase) {
            indirizzoPagina = "DashboardCliente.jsp";
            
            HttpSession session = request.getSession();
            String idSession = session.getId();
            clienti = new Clienti(idCliente, nome, cognome, null, null, null);
            session.setAttribute("Login", clienti);
            
            /**
            * Questo cookie setta l'id del Cliente per una settimana e
            * Questo valore viene utilizzato solo dalla Servlet
            * VisualizzaPrenotazioni Nessun motivo in particolare per
            * questo l'ho utilizzato, per sperimentare.
            */
            Cookie cookie = new Cookie("idCliente", String.valueOf(clienti.getIdCliente()));
            cookie.setMaxAge(60 * 60 * 24 * 7);
            response.addCookie(cookie);
        }
       
        if (esisteValoreInDatabase == false) {
            indirizzoPagina = "Utente.jsp";
            request.setAttribute("UtenteNonTrovato", "Utente Non Trovato");
        }

        RequestDispatcher di = request.getRequestDispatcher(indirizzoPagina);
        di.forward(request, response);

    }
}

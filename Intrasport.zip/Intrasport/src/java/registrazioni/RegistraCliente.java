/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registrazioni;

import java.io.IOException;
import java.sql.Connection;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Registra un Cliente e memorizza i dati  nel database i dati provengono da Utente.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "RegistraCliente", urlPatterns = {"/RegistraCliente"})
public class RegistraCliente extends HttpServlet {

    private Connection conn;
    private PreparedStatement prs;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(RegistraCliente.class.getName()).log(Level.SEVERE, null, ex);

        }

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(RegistraCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Date dataNascita = null;
        String nome = request.getParameter("nome");
        String cognome = request.getParameter("cognome");
        String giorno = request.getParameter("giorno");
        String mese = request.getParameter("mese");
        String anno = request.getParameter("anno");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        boolean Error = false;
        String indirizzoPagina = "";

        String sql = "INSERT into clienti(nome,cognome,datadinascita,username,password) VALUES(?,?,?,?,?)";

        try {
            if (nome == "" || cognome == "" || username == "" || password == "") {
                throw new NullPointerException();
            }

            dataNascita = Date.valueOf(anno + "-" + mese + "-" + giorno);

            prs = conn.prepareStatement(sql);
            prs.setString(1, nome);
            prs.setString(2, cognome);
            prs.setDate(3, dataNascita);
            prs.setString(4, username);
            prs.setString(5, password);
            prs.executeUpdate();

        } catch (SQLException | IllegalArgumentException ex) {
            Logger.getLogger(RegistraCliente.class.getName()).log(Level.SEVERE, null, ex);
            Error = true;

        } catch (NullPointerException e) {
            Error = true;

        }

        if (Error) {
            indirizzoPagina = "Utente.jsp";
            request.setAttribute("inputNonValido", "Input non valido");
            RequestDispatcher disp = request.getRequestDispatcher(indirizzoPagina);
            disp.forward(request, response);
        } else {
            indirizzoPagina = "RegistrazioneEffettuata.jsp";
            request.setAttribute("nome", nome);
            request.setAttribute("cognome", cognome);
            request.setAttribute("dataNascita", dataNascita);
            request.setAttribute("username", username);
            request.setAttribute("password", password);
        }

        RequestDispatcher di = request.getRequestDispatcher(indirizzoPagina);
        di.forward(request, response);

    }

}

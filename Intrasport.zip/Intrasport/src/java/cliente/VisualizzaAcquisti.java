/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.Clienti;
import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * La sevlet viene invocata da DaschboardCliente.jsp Visualizza GLi acquisti
 * fatti manda i dati a VisualizzaAcquisti.jsp i dati vengono presi dalla
 * tabella prenotaacquista
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "VisualizzaAcquisti", urlPatterns = {"/VisualizzaAcquisti"})
public class VisualizzaAcquisti extends HttpServlet {
    
    private Connection con;
    private PreparedStatement prs;
    private DatiPartite p;
    private Clienti c;
    private ArrayList<DatiPartite> partite;
    
    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(VisualizzaAcquisti.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaAcquisti.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        partite = new ArrayList<>();
        
        boolean esistePartitaAcquistata = false;
        String indirizzoPagina = "VisualizzaAcquisti.jsp";
        
        HttpSession sess = request.getSession();
        Clienti clienti = (Clienti) sess.getAttribute("Login");
        
        String sql = "SELECT idpartita ,nome,cognome, squadra1, squadra2, stadio, ora, periodo, p.biglietti,p.prezzototale\n"
                + "FROM prenotaacquista p , clienti c, dati d\n"
                + "WHERE p.IDCLIENTE = (?) and c.IDCLIENTE = (?) and p.ACQUISTA = d.IDPARTITA and p.ACQUISTA <> 0";
        
        try {
            prs = con.prepareStatement(sql);
            prs.setInt(1, clienti.getIdCliente());
            prs.setInt(2, clienti.getIdCliente());
            ResultSet rs = prs.executeQuery();
            
            while (rs.next()) {
                
                int idPartita = rs.getInt("idpartita");
                String nome = rs.getString("nome");
                String cognome = rs.getString("cognome");
                String squadra1 = rs.getString("squadra1");
                String squadra2 = rs.getString("squadra2");
                String stadio = rs.getString("stadio");
                Time ora = rs.getTime("ora");
                Date periodo = rs.getDate("periodo");
                int biglietti = rs.getInt("biglietti");
                double prezzoTotale = rs.getDouble("prezzoTotale");
                
                c = new Clienti(0, nome, cognome, null, null, null);
                p = new DatiPartite(idPartita, squadra1, squadra2, stadio, prezzoTotale, ora, periodo, 0, biglietti);
                
                partite.add(p);
                
                esistePartitaAcquistata = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaAcquisti.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (esistePartitaAcquistata) {
            request.setAttribute("clientee", c);
            request.setAttribute("partitaAcquistate", partite);
        } else {
            
            request.setAttribute("error", "Nessuna Partita Acquistata");
        }
        
        RequestDispatcher di = request.getRequestDispatcher(indirizzoPagina);
        di.forward(request, response);
    }
    
}

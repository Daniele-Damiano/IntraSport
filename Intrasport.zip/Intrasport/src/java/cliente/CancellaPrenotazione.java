/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.Clienti;
import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Seleziona i biglietti dalla tabella dati, aggiunge i biglietti non piu
 * prenotati aggiorna la tabella dati con le nuove modifiche, e cancella la
 * prenotazione Cancella una Prenotazione in base all'id del cliente e l'id
 * della partita che si trova nella colona prenota della tabella prenotaacquista
 * questa servlet manda i dati a PrenotazioneCancellataConsuccesso.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "CancellaPrenotazione", urlPatterns = {"/CancellaPrenotazione"})
public class CancellaPrenotazione extends HttpServlet {

    private Connection con;
    private PreparedStatement prs7;
    private PreparedStatement prs8;
    private PreparedStatement prs9;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(PartitaSelezionata.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(PartitaSelezionata.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int bigliettiNonPiuPrenotati = 0, biglietti = 0;
        int idPartita = Integer.valueOf(request.getParameter("id"));

        HttpSession sess = request.getSession();
        Clienti c = (Clienti) sess.getAttribute("Login");
        ArrayList<DatiPartite> partitePrenotate = (ArrayList<DatiPartite>) sess.getAttribute("datiPartitaPrenotata");

        for (DatiPartite d : partitePrenotate) {
            if (d.getId() == idPartita) {
                bigliettiNonPiuPrenotati = d.getBiglietti();
            }
        }

        /**
         * Seleziona i biglietti dalla tabella dati, aggiunge i biglietti non
         * piu prenotati aggiorna la tabella dati con le nuove modifiche, e
         * cancella la prenotazione
         */
        String sql1 = "SELECT biglietti from dati where idpartita = (?)";
        String sql2 = "UPDATE dati SET biglietti = (?) where idpartita = (?)";
        String sql3 = "DELETE from prenotaacquista where idCliente = (?) and prenota = (?)";

        try {
            prs7 = con.prepareStatement(sql1);
            prs7.setInt(1, idPartita);
            ResultSet rs = prs7.executeQuery();

            while (rs.next()) {
                biglietti = rs.getInt("biglietti");
            }

            int aggiungiBigliettiNonPiuPrenotati = bigliettiNonPiuPrenotati + biglietti;

            prs8 = con.prepareStatement(sql2);
            prs8.setInt(1, aggiungiBigliettiNonPiuPrenotati);
            prs8.setInt(2, idPartita);
            prs8.executeUpdate();

            prs9 = con.prepareStatement(sql3);
            prs9.setInt(1, c.getIdCliente());
            prs9.setInt(2, idPartita);
            prs9.executeUpdate();

        } catch (SQLException e) {
            Logger.getLogger(CancellaPrenotazione.class.getName()).log(Level.SEVERE, null, e);
        }

        request.setAttribute("prenotazioneCancellata", "Prenotazione Cancellata");
        RequestDispatcher di = request.getRequestDispatcher("PrenotazioneCancellataConsuccesso.jsp");
        di.forward(request, response);

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Calcola il Prezzo Della Partita Selezionata
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "CalcolaPrezzoSenzaAccedere", urlPatterns = {"/CalcolaPrezzoSenzaAccedere"})
public class CalcolaPrezzoSenzaAccedere extends HttpServlet {

    private DatiPartite d;

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int numeroBilietti = 0;
        double prezzoBiglietto = 0;
        boolean errore = false;

        HttpSession sess = request.getSession();
        d = (DatiPartite) sess.getAttribute("AcquistaPartitaSenzaAccedere");

        try {
            String num = request.getParameter("numeroBiglietti");
            if (num == "") {
                throw new NullPointerException();
            }

            numeroBilietti = Integer.valueOf(num);

            controlloBiglietto(numeroBilietti, d.getBiglietti());

        } catch (NullPointerException | IllegalArgumentException e) {
            errore = true;
        }

        if (errore) {
            request.setAttribute("ErroreBiglietto", "Errore Input");
        } else {
            prezzoBiglietto = d.getPrezzo() * numeroBilietti;
            request.setAttribute("PrezzoBiglietto", prezzoBiglietto);
        }

        RequestDispatcher dis = request.getRequestDispatcher("PartitaSelezionatasenzaAccedere.jsp");
        dis.forward(request, response);
    }

    /**
     *
     * @param numeroBiglietti Il numero di biglietti che inserisci l'utente da
     * comprare
     * @param bigliettiDisponibili i biglietti che sono disponibbili per la
     * partita
     * @throws IllegalArgumentException se il numero di biglietti e 0, oppure <0
     * oppure supera i biglietti disponibili
     */
    public void controlloBiglietto(int numeroBiglietti, int bigliettiDisponibili) throws IllegalArgumentException {
        if (numeroBiglietti == 0 || numeroBiglietti < 0 || numeroBiglietti > d.getBiglietti()) {
            throw new IllegalArgumentException();
        }
    }

}

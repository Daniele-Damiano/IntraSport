/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.Clienti;
import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Visualizza tutte le prenotazioni effettuate da un Cliente la servlet viene
 * invocata da DashboardCliente.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "VisualizzaPrenotazioni", urlPatterns = {"/VisualizzaPrenotazioni"})
public class VisualizzaPrenotazioni extends HttpServlet {

    private Connection con;
    private PreparedStatement prs13;

    private DatiPartite datiPartite;
    private boolean esistePrenotaziome;
    private String indirizzoPagina = "";
    private ArrayList<DatiPartite> partite;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(VisualizzaPrenotazioni.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        if (con != null) {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(VisualizzaPrenotazioni.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         /**
         *
         * Preleva dal database clienti, nome cognome e numero di biglietti in
         * base all'id del cliente, preleva dal database dati, le squadre lo
         * stadio ora e periodo d'inizio, dove l'id del cliente e quello
         * prlevato dal cookie, cioe quello che si e registrato e preso in
         * input, prenota e = all'id della partita che e memorizzata del
         * database dati, e deve essere diverso da 0 <>0 cioe deve aver
         * prenotato una partita se e 0 EsistePrenotazione e false non ha
         * prenotato nulla e visualizza il mesaggio non hai prenotato la partita
         * le prenotazioni vengono visualizzate solo se si e nellagiornata
         * corrente anche le partite sono visualizzate cosi.
         *
         *   /**
         * Se e stata trovata una prenotazione cioe che la colonna prenota ha al
         * suo inteno l'id della partita che ha prenotato.
         */
         

        partite = new ArrayList<>();

        HttpSession sess = request.getSession();
        Clienti c = (Clienti) sess.getAttribute("Login");

       
        String sql = "SELECT idpartita, squadra1, squadra2, stadio, ora, periodo, p.biglietti\n"
                + "FROM prenotaacquista p, clienti c, dati d\n"
                + "WHERE p.IDCLIENTE =  (?) and c.IDCLIENTE = (?) and p.PRENOTA = d.IDPARTITA and p.PRENOTA <> 0\n"
                + "and ora > CURRENT_TIME and periodo = CURRENT_DATE";

        try {

            prs13 = con.prepareStatement(sql);
            prs13.setInt(1, c.getIdCliente());
            prs13.setInt(2, c.getIdCliente());
            ResultSet rs = prs13.executeQuery();

            while (rs.next()) {

                int idPartita = rs.getInt("idpartita");
                String squadra1 = rs.getString("squadra1");
                String squadra2 = rs.getString("squadra2");
                String stadio = rs.getString("stadio");
                Time ora = rs.getTime("ora");
                Date periodo = rs.getDate("periodo");
                int biglietti = rs.getInt("biglietti");

                datiPartite = new DatiPartite(idPartita, squadra1, squadra2, stadio, 0, ora, periodo, 0, biglietti);
                partite.add(datiPartite);

                esistePrenotaziome = true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaPrenotazioni.class.getName()).log(Level.SEVERE, null, ex);
        }

      
        if (esistePrenotaziome) {

            indirizzoPagina = "VisualizzaPartitePrenotate.jsp";
            sess.setAttribute("datiPartitaPrenotata", partite);

        } else {
            indirizzoPagina = "VisualizzaPartitePrenotate.jsp";
            request.setAttribute("nessunaPrenotazione", "Nessuna Partita Prenotata");
        }

        RequestDispatcher dis = request.getRequestDispatcher(indirizzoPagina);
        dis.forward(request, response);

    }

}

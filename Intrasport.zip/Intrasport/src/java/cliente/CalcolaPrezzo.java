/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Calcola il prezzo della partita acquistata in base ai biglietti 
 * la servlet viene chiamata da acquista.jsp
 * 
 * 
 * @author Damiano Daniele
 */
@WebServlet(name = "CalcolaPrezzo", urlPatterns = {"/CalcolaPrezzo"})
public class CalcolaPrezzo extends HttpServlet {
    private double PrezzoTotale = 0;
    

    
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String indirizzoPagina = null;
        /**
         * Prende la partita dalla sessione se e stata prenotata
         */
        HttpSession session = request.getSession();
        DatiPartite  datiPartite = (DatiPartite)session.getAttribute("PartitaInSessione");
       
        
        /**
         * Calcola il prezzo per i biglietti
         */
        PrezzoTotale = datiPartite.getBiglietti() * datiPartite.getPrezzo();
        
       
        indirizzoPagina = "Acquista.jsp";
       
        request.setAttribute("PrezzoPartita", PrezzoTotale);
        RequestDispatcher dis = request.getRequestDispatcher(indirizzoPagina);
        dis.forward(request, response);
        
    }

  
}

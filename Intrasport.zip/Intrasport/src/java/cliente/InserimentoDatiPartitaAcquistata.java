/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.Clienti;
import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Aggiorna la tabella dati scalando i biglietti che ha acquistato il cliente per
 * questa partita.
 * Inserisce nella tabellaprenotaacquista l'id della partita acquistata, i biglietti acquistati
 * il prezzo e l'id del cliente.
 * 
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "InserimentoDatiPartitaAcquistata", urlPatterns = {"/InserimentoDatiPartitaAcquistata"})
public class InserimentoDatiPartitaAcquistata extends HttpServlet {

    private Connection con;
    private PreparedStatement prs;
    private PreparedStatement prs1;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (ClassNotFoundException | SQLException e) {
            Logger.getLogger(InserimentoDatiPartitaAcquistata.class.getName()).log(Level.SEVERE, null, e);
        }

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(InserimentoDatiPartitaAcquistata.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        boolean errore = false;
        double prezzoTotale = 0;
        int biglietti = 0;
        String indirizzoPagina = "PartitaNonPrenotataAcquistata.jsp";
        /**
         * Preleva i dati della partita e i dati del cliente dalla sessione.
         *
         * Prende dal form AcquistaPartiteNonPrenotate.jsp dal campo hidden
         * prezzoTotale per prendere il prezzo calcolato da
         * CalcolaPrezzoNonPrenotata
         *
         * Preleva il numero di biglietti acquistati dal form che si trova in
         * AcquistaPartiteNonPrenotate.jsp e li converte in intero.
         *
         * sottrai i biglietti che ha acquistato il cliente dai biglietti
         * disponibili per la la partita in questione
         *
         * Calcola il prezzo dei biglietti acquistati.
         * 
         * controlla i biglietti che l'utente acquista se sono 0, se e un
         * numeero negativo o se il numero di biglietti che si vuole acquistare
         * supera quelli disponibili
         */

        HttpSession sess = request.getSession();
        Clienti clienti = (Clienti) sess.getAttribute("Login");
        DatiPartite partite = (DatiPartite) sess.getAttribute("PartitaSelezionata");

        String sql = "UPDATE dati set biglietti = (?) where idpartita = (?)";
        String sql1 = "INSERT INTO prenotaacquista(idcliente,acquista,biglietti,prezzototale) values(?,?,?,?)";

        try {

            String bigliettiAcqui = request.getParameter("numeroBigliettiAcquistati");
            if (bigliettiAcqui == "") {
                throw new NullPointerException();
            }
            biglietti = Integer.valueOf(bigliettiAcqui);
            
            controlloBiglietti(biglietti, partite.getBiglietti());

            int scaloBigliettiDaPartita = partite.getBiglietti() - biglietti;

            prezzoTotale = partite.getPrezzo() * biglietti;
            
            prs = con.prepareStatement(sql);
            prs1 = con.prepareStatement(sql1);

            prs.setInt(1, scaloBigliettiDaPartita);
            prs.setInt(2, partite.getId());
            prs.executeUpdate();
            
            prs1.setInt(1, clienti.getIdCliente());
            prs1.setInt(2, partite.getId());
            prs1.setInt(3, biglietti);
            prs1.setDouble(4, prezzoTotale);
            prs1.executeUpdate();

        } catch (NullPointerException | IllegalArgumentException |SQLException e) {
            errore = true;
        }
        if (errore) {
            indirizzoPagina = "AcquistaPartiteNonPrenotate.jsp";
            request.setAttribute("Errore", "Errore Input");
        } else {
            
            request.setAttribute("prezzoTotale", prezzoTotale);
            request.setAttribute("bigliettiAcquistati", biglietti);
        }
        RequestDispatcher di = request.getRequestDispatcher(indirizzoPagina);
        di.forward(request, response);
    }

    /**
     * Controlla il numero di biglietti per la partita in questione
     *
     * @param numeroDiBigliettiAcquistati il numero di biglietti che si desider
     * acquistare
     * @param numeroBigliettiDisponibili il numero di bilgietti disponibili per
     * la partita in questione
     * @throws IllegalArgumentException se l'utente iserisce in input 0, o un
     * numero negativo, o se i biglietti che desidera acquistare sono maggiori
     * di quelli disponibili
     */
    public void controlloBiglietti(int numeroDiBigliettiAcquistati, int numeroBigliettiDisponibili) throws IllegalArgumentException {
        if (numeroDiBigliettiAcquistati == 0 || numeroDiBigliettiAcquistati < 0 || numeroDiBigliettiAcquistati > numeroBigliettiDisponibili) {
            throw new IllegalArgumentException();
        }
    }

}

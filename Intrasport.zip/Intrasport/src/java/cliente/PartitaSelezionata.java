/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Questa servlet viene invocata da VisualizzaPartiteUtente.jsp <c:url>
 * Mostra i dettagli di una partita e se prenotarla o acquistarla
 * in base all'id della url seleziona la partita dal database
 * @author Daniele Damiano
 */
@WebServlet(name = "PartitaSelezionata", urlPatterns = {"/PartitaSelezionata"})
public class PartitaSelezionata extends HttpServlet {

    private Connection con;
    private PreparedStatement prs;
    private DatiPartite dati;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(PartitaSelezionata.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        if (con != null) {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(PartitaSelezionata.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        /* /**                                                                                      
        * Seleziona la partita dalla tabella Dati in base all'id e la mette nella
        * Sessione con il nome PartitaSelezionata, fa il forward a PartitaSelezionata.jsp
        *
        *
        *
        */

        String id = request.getParameter("id");

        String sql = "SELECT * FROM dati WHERE idpartita = (?)";

        try {
            prs = con.prepareStatement(sql);
            prs.setString(1, id);
            ResultSet rs = prs.executeQuery();

            while (rs.next()) {
                int id1 = rs.getInt("idpartita");
                String squadra1 = rs.getString("squadra1");
                String squadra2 = rs.getString("squadra2");
                String stadio = rs.getString("stadio");
                double prezzo = rs.getDouble("prezzo");
                Time ora = rs.getTime("ora");
                Date periodo = rs.getDate("periodo");
                double capienza = rs.getDouble("capienza");
                int biglietti = rs.getInt("biglietti");

                dati = new DatiPartite(id1, squadra1, squadra2, stadio, prezzo, ora, periodo, capienza, biglietti);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PartitaSelezionata.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HttpSession sess = request.getSession();
        sess.setAttribute("PartitaSelezionata", dati);
        
       
        RequestDispatcher di = request.getRequestDispatcher("PartitaSelezionata.jsp");
        di.forward(request, response);

    }
}

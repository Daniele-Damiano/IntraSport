/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.Clienti;
import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Il cliente prenota i biglietti per la partita e li scala dai biglietti che ci
 * sono disponibili aggiornando la tabella dati nella colonna biglietti, se la partita e stata gia prenotata
 * agiorna la tabella prenotaacquista se non e stata gia prenotata, 
 * inserisce nella tabella prenotaacquista l'id del cliente,la partita prenotata
 * nella colonna PRENOTA si memorizza l'id della partita, e il numero di
 * biglietti prenotati i dati provengono da PrenotaPartite.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "Prenota", urlPatterns = {"/Prenota"})
public class Prenota extends HttpServlet {

    private Connection con;
    private PreparedStatement prs5;
    private PreparedStatement prs10;
    private PreparedStatement prs11;
    private PreparedStatement prs12;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(Prenota.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        if (con != null) {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(Prenota.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        /**
         * Converte i biglietti in intero li sottrai dai biglietti disponibbili
         * li aggiorna nella tabella dati e li inserisce in prenotaacquista i
         * dati Provengono da PrenotaPartite.jsp
         *
         */

        HttpSession sess = request.getSession();
        DatiPartite partite = (DatiPartite) sess.getAttribute("PartitaSelezionata");
        Clienti cliente = (Clienti) sess.getAttribute("Login");

        String indirizzoPagina = "";

        boolean Error = false;
        boolean laPartitaPrenotataEsisteGia = false;
        int biglPrenotati = 0, bigliettiPrenotatiGiaEsistentiNelDatabase = 0, bigliettiTotali = 0;

        String bigli = request.getParameter("bigliettiPrenotati");

        String sql1 = "UPDATE DATI set biglietti = (?) where idPartita = (?)";
        String sql2 = "SELECT biglietti from prenotaacquista where idcliente = (?) and prenota = (?)";
        String sql3 = "UPDATE prenotaacquista set biglietti = (?) where idcliente = (?) and prenota = (?)";
        String sql4 = "INSERT into prenotaacquista(idcliente,prenota,biglietti) values (?,?,?)";

        try {
            if (bigli == "") {
                throw new NullPointerException();
            }

            biglPrenotati = Integer.valueOf(bigli);

            controlloValoreBiglietto(biglPrenotati, partite.getBiglietti());

            int bigliettiScalati = partite.getBiglietti() - biglPrenotati;

            prs5 = con.prepareStatement(sql1);
            prs5.setInt(1, bigliettiScalati);
            prs5.setInt(2, partite.getId());
            prs5.executeUpdate();

            prs10 = con.prepareStatement(sql2);
            prs10.setInt(1, cliente.getIdCliente());
            prs10.setInt(2, partite.getId());
            ResultSet rs = prs10.executeQuery();

            while (rs.next()) {
                bigliettiPrenotatiGiaEsistentiNelDatabase = rs.getInt("biglietti");
                laPartitaPrenotataEsisteGia = true;
            }

            if (laPartitaPrenotataEsisteGia) {
                bigliettiTotali = bigliettiPrenotatiGiaEsistentiNelDatabase+biglPrenotati;
                prs11 = con.prepareStatement(sql3);
                prs11.setInt(1, bigliettiTotali);
                prs11.setInt(2, cliente.getIdCliente());
                prs11.setInt(3, partite.getId());
                prs11.executeUpdate();
            } else {

                prs12 = con.prepareStatement(sql4);
                prs12.setInt(1, cliente.getIdCliente());
                prs12.setInt(2, partite.getId());
                prs12.setInt(3, biglPrenotati);
                prs12.executeUpdate();
            }

        } catch (SQLException | IllegalArgumentException | NullPointerException e) {
            Logger.getLogger(Prenota.class.getName()).log(Level.SEVERE, null, e);
            Error = true;
        }

        if (Error) {
            indirizzoPagina = "PrenotaPartite.jsp";
            request.setAttribute("InputBigliettoNonValido", "Errore Input");
        } else {
            indirizzoPagina = "PrenotazioneEffettuataConSuccesso.jsp";
        }

        RequestDispatcher dis = request.getRequestDispatcher(indirizzoPagina);
        dis.forward(request, response);
    }

    /**
     * Controlla i biglietti in input
     *
     * @param bigliettiPrenotati i biglietti che prenota il cliente
     * @param bigliettiDatabase i biglietti che sono disponibili
     * @throws IllegalArgumentException se l'input che inserisce l'utente e = 0,
     * <0 oppure i biglietti prenotati sono maggiori di quelli disponibili
     */
    public void controlloValoreBiglietto(int bigliettiPrenotati, int bigliettiDatabase) throws IllegalArgumentException {

        if (bigliettiPrenotati == 0 || bigliettiPrenotati < 0 || bigliettiPrenotati > bigliettiDatabase) {
            throw new IllegalArgumentException();

        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.Clienti;
import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Aggiorna la tabella del database prenotaacquista se la partita e prenotata
 * aggiorna la tabella mettendo l'id della partita dalla colonna prenota e lo
 * mette nella colona acquista e setta il prezzo totale nella colonna
 * prezzototale. I dati provengono da acquista.jsp.e questa
 * servlet viene chiamata da acquista.jsp. e manda i dati a
 * PartitaAcquistata.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "AggiornamentoDatiPartitaAcquistata", urlPatterns = {"/AggiornamentoDatiPartitaAcquistata"})
public class AggiornamentoDatiPartitaAcquistata extends HttpServlet {

    private Connection con;
    private PreparedStatement prs;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(AggiornamentoDatiPartitaAcquistata.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(AggiornamentoDatiPartitaAcquistata.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sess = request.getSession();
        DatiPartite partite = (DatiPartite) sess.getAttribute("PartitaInSessione");
        Clienti clienti = (Clienti) sess.getAttribute("Login");

        double prezzoTotale = partite.getPrezzo() * partite.getBiglietti();

        String sql = "UPDATE prenotaacquista set acquista = (?), prenota = 0, prezzototale = (?)\n"
                + "where idcliente = (?) and prenota = (?)";

        try {
            prs = con.prepareStatement(sql);
            prs.setInt(1, partite.getId()); //id parttia
            prs.setDouble(2, prezzoTotale);
            prs.setInt(3, clienti.getIdCliente());
            prs.setInt(4, partite.getId()); // id partita
            prs.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(AggiornamentoDatiPartitaAcquistata.class.getName()).log(Level.SEVERE, null, ex);
        }

       request.setAttribute("prezzo", prezzoTotale);
        RequestDispatcher di = request.getRequestDispatcher("PartitaAcquistata.jsp");
        di.forward(request, response);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Calcola il prezzo della partita non prenotata in base ai biglietti i dati
 * provengono da AcquistaPartiteNonPrenotate.jsp e li manda a
 * AcquistaPartiteNonPrenotate.jsp
 *
 * @author HDaniele Damiano
 */
@WebServlet(name = "CalcoloPrezzoNonPrenotata", urlPatterns = {"/CalcoloPrezzoNonPrenotata"})
public class CalcoloPrezzoNonPrenotata extends HttpServlet {

    private DatiPartite d;

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String indirizzoPagina = "AcquistaPartiteNonPrenotate.jsp";
        boolean errore = false;
        double prezzoTotale = 0;
        int bigl = 0;
        /**
         * Prende dalla sessione i dati della partita per calcolare il prezzo
         * del biglietto di quanti biglietti ha comprato il clienti i dati nella
         * sessione sono stati messi dalla servlet AcquistoPartitaNonPrenotata
         *
         * Converte i biglietti presi in input
         *
         * controlla i biglietti se hano un numero negativo, o se sono 0, o se
         * sono maggiori dei biglietti disponibili calcola il prezzo del
         * biglietto
         */

        HttpSession sess = request.getSession();
        d = (DatiPartite) sess.getAttribute("PartitaSelezionata");

        try {
            String biglietti = request.getParameter("NumeroBiglietti");
            if (biglietti == "") {
                throw new NullPointerException();
            }
            bigl = Integer.valueOf(biglietti);
            controlloNumeroBiglietti(bigl, d.getBiglietti());

        } catch (NullPointerException | IllegalArgumentException e) {
            errore = true;
        }
        if (errore) {
            request.setAttribute("errore", "Errore");
        } else {
            prezzoTotale = bigl * d.getPrezzo();
            request.setAttribute("PrezzoPartita", prezzoTotale);
        }
        RequestDispatcher dis = request.getRequestDispatcher(indirizzoPagina);
        dis.forward(request, response);

    }

    /**
     * Controllo il numero di biglietti
     *
     * @param bigliettoCheVuoleAcquistare il numero di biglietti che l'utente
     * vuole acquistare
     * @param bigliettoPartita il numero di biglietti disponibili per la partita
     * in questione
     * @throws IllegalArgumentException se l'utente inserisce 0 o un numero
     * negativo o i biglietti che vuole acquistare sono maggiori dei biglietti
     * disponibili
     */
    public void controlloNumeroBiglietti(int bigliettoCheVuoleAcquistare, int bigliettoPartita) throws IllegalArgumentException {
        if (bigliettoCheVuoleAcquistare == 0 || bigliettoCheVuoleAcquistare < 0 || bigliettoCheVuoleAcquistare > bigliettoPartita) {
            throw new IllegalArgumentException();
        }

    }

}

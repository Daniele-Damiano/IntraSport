/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * La servlet viene invocata da PartitaSelezionataSenzaAccedere.jsp Acquista la
 * partita, preleva i dati dalla sessione che li ha messi la servlet
 * AcquistaPartitaSenzaAccedere Inserisce nome,cognome,idpartita,biglietti
 * acquistati, prezzo in una tabella acquistapartitasenzaaccedere
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "AcquistaPartitaSenzaAccedere", urlPatterns = {"/AcquistaPartitaSenzaAccedere"})
public class AcquistaPartitaSenzaAccedere extends HttpServlet {

    private DatiPartite partite;
    private Connection con;
    private PreparedStatement prs3;
    private PreparedStatement prs4;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(AcquistaPartitaSenzaAccedere.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(AcquistaPartitaSenzaAccedere.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        /**
         * Prende i dati della partita in questione dalla sessione scala dalla
         * partita il numero di biglietti che il cliente vuole acquistare
         * calcola il prezzo e aggiorna la tabella dati, e poi inserisce i dati
         * nella tabella acquistapartitesenzaaccedere.
         */
        boolean errore = false;
        String indirizzoPagina = "";
        int numeroBigliettiAcquistati = 0;
        double prezzoBigliettiAcquistati = 0;

        HttpSession sess = request.getSession();
        partite = (DatiPartite) sess.getAttribute("AcquistaPartitaSenzaAccedere");

        String sql = "UPDATE dati set biglietti = (?) where idpartita = (?)";
        String sql1 = "INSERT INTO ACQUISTAPARTITASENZAACCEDERE(IDPARTITA,NOME,COGNOME,BIGLIETTIACQUISTATI,PREZZO)"
                + "values(?,?,?,?,?)";

        try {
            String nome = request.getParameter("nome");
            String cognome = request.getParameter("cognome");
            String bigl = request.getParameter("numeroBigl");

            if (nome == "" || cognome == "" || bigl == "") {
                throw new NullPointerException();
            }

            numeroBigliettiAcquistati = Integer.valueOf(bigl);
            controlloNumeroBiglietti(numeroBigliettiAcquistati, partite.getBiglietti());

            int numeroBiglietti = partite.getBiglietti() - numeroBigliettiAcquistati;

            prezzoBigliettiAcquistati = partite.getPrezzo() * numeroBigliettiAcquistati;

            prs3 = con.prepareStatement(sql);
            prs4 = con.prepareStatement(sql1);

            prs3.setInt(1, numeroBiglietti);
            prs3.setInt(2, partite.getId());
            prs3.executeUpdate();

            prs4.setInt(1, partite.getId());
            prs4.setString(2, nome);
            prs4.setString(3, cognome);
            prs4.setInt(4, numeroBigliettiAcquistati);
            prs4.setDouble(5, prezzoBigliettiAcquistati);
            prs4.executeUpdate();

        } catch (NullPointerException | IllegalArgumentException | SQLException e) {
            errore = true;
        }

        if (errore) {
            indirizzoPagina = "PartitaSelezionatasenzaAccedere.jsp";
            request.setAttribute("Errore", "Errore Input");
        } else {
            indirizzoPagina = "PartitaSenzaAccedereAcquistataConSUccesso.jsp";
            request.setAttribute("prezzo", prezzoBigliettiAcquistati);
            request.setAttribute("biglietti", numeroBigliettiAcquistati);
        }

        RequestDispatcher dis = request.getRequestDispatcher(indirizzoPagina);
        dis.forward(request, response);

    }
    
    /**
     * Controllo il numero di biglietti
     *
     * @param bigliettoCheVuoleAcquistare il numero di biglietti che l'utente
     * vuole acquistare
     * @param bigliettoPartita il numero di biglietti disponibili per la partita
     * in questione
     * @throws IllegalArgumentException se l'utente inserisce 0 o un numero
     * negativo o i biglietti che vuole acquistare sono maggiori dei biglietti
     * disponibili
     */
    public void controlloNumeroBiglietti(int bigliettoCheVuoleAcquistare, int bigliettoPartita) throws IllegalArgumentException {
        if (bigliettoCheVuoleAcquistare == 0 || bigliettoCheVuoleAcquistare < 0 || bigliettoCheVuoleAcquistare > bigliettoPartita) {
            throw new IllegalArgumentException();
        }

    }

}

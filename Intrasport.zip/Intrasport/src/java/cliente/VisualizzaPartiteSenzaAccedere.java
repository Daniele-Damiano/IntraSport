/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * La servlet viene chiamata da index.html
 * Acquista Partite senza accedere all'sistema manda i dati ad 
 * AcquistaPartiteSenzaAccedere.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "VisualizzaPartiteSenzaAccedere", urlPatterns = {"/VisualizzaPartiteSenzaAccedere"})
public class VisualizzaPartiteSenzaAccedere extends HttpServlet {

    private Connection con;
    private PreparedStatement prs;
    private DatiPartite datiPartite;
    private ArrayList<DatiPartite> partite;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(VisualizzaPartiteSenzaAccedere.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaPartiteSenzaAccedere.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        partite = new ArrayList<>();

        String sql = "SELECT IDPARTITA, SQUADRA1,SQUADRA2,STADIO,PREZZO,ORA,PERIODO,BIGLIETTI FROM dati\n"
                + "where ora > CURRENT_TIME and periodo = CURRENT_DATE";

        try {
            prs = con.prepareStatement(sql);
            ResultSet rs = prs.executeQuery();

            while (rs.next()) {

                int idpartitaa = rs.getInt("idpartita");
                String squadra1 = rs.getString("squadra1");
                String squadra2 = rs.getString("squadra2");
                String stadio = rs.getString("stadio");
                double prezzo = rs.getDouble("prezzo");
                Time ora = rs.getTime("ora");
                Date periodo = rs.getDate("periodo");
                int biglietti = rs.getInt("biglietti");

                datiPartite = new DatiPartite(idpartitaa, squadra1, squadra2, stadio, prezzo, ora, periodo, 0, biglietti);
                partite.add(datiPartite);
            }
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaPartiteSenzaAccedere.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        request.setAttribute("partiteSenzaAccedere", partite);
        
        RequestDispatcher dis = request.getRequestDispatcher("AcquistaPartitaSenzaAccedere.jsp");
        dis.forward(request, response);

    }
}

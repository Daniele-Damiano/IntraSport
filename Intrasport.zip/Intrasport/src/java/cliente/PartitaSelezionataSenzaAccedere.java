/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * La servlet viene invocata da AcquistaPartitaSenzaAccedere.jsp Prende in input
 * l'id della partita e la cerca nella tabella dati I dati provengono da
 * AcquistaPartitaSenzaAccedere.jsp e li manda a PartitaSelezionatasenzaAccedere.jsp
 *
 * @author Damiano Daniele
 */
@WebServlet(name = "PartitaSelezionataSenzaAccedere", urlPatterns = {"/PartitaSelezionataSenzaAccedere"})
public class PartitaSelezionataSenzaAccedere extends HttpServlet {

    private Connection con;
    private PreparedStatement prs2;
    private DatiPartite d;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(PartitaSelezionataSenzaAccedere.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(PartitaSelezionataSenzaAccedere.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("idPa");
        int idPartita = Integer.valueOf(id);

        String sql = "SELECT IDPARTITA, SQUADRA1,SQUADRA2,STADIO,PREZZO,ORA,PERIODO,BIGLIETTI FROM dati\n"
                + "where idpartita = (?)";

        try {
            prs2 = con.prepareStatement(sql);
            prs2.setInt(1, idPartita);
            ResultSet rs = prs2.executeQuery();

            while (rs.next()) {

                int idpartita = rs.getInt("IDPARTITA");
                String squadra1 = rs.getString("squadra1");
                String squadra2 = rs.getString("squadra2");
                String stadio = rs.getString("stadio");
                double prezzo = rs.getDouble("prezzo");
                Time ora = rs.getTime("ora");
                Date periodo = rs.getDate("periodo");
                int biglietti = rs.getInt("biglietti");

                d = new DatiPartite(idpartita, squadra1, squadra2, stadio, prezzo, ora, periodo, 0, biglietti);

            }
        } catch (SQLException e) {
            Logger.getLogger(PartitaSelezionataSenzaAccedere.class.getName()).log(Level.SEVERE, null, e);
        }
        HttpSession sess = request.getSession();
        sess.setAttribute("AcquistaPartitaSenzaAccedere", d);

        RequestDispatcher dis = request.getRequestDispatcher("PartitaSelezionatasenzaAccedere.jsp");
        dis.forward(request, response);

    }

}

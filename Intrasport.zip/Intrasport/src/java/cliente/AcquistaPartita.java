/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.Clienti;
import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * La servlet viene invocata da partitaSelezionata.jsp Acquista un apartita che
 * e stata gia prenotata, oppure una partita non prenotata, se lapartita non e
 * stata prenotata invia il controllo alla pagina AcquistaPartiteNonPrenotate.jsp
 *
 *
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "AcquistaPartita", urlPatterns = {"/AcquistaPartita"})
public class AcquistaPartita extends HttpServlet {

    private Connection con;
    private PreparedStatement prs;
    private DatiPartite datiPartite;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(AcquistaPartita.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(AcquistaPartita.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        boolean clienteHaPrenotatoPartita = false;
        String indirizzoPagina = null;

        /**
         * Preleva l'id cliente dalla sessione questa volta ho usato HttpSession
         * per nessun motivo in particolare solo per sperimentare. Una volta ho
         * prelevato l'id del cliente dai cookie e una volta dalla sessione,
         * solo per sperimentare nessuna motivazione in particolare. /**
         * confronta i dati della tabella prenotaacquista con dati per vedere se
         * e stata prenotata una partita se la partita e stata prenotata va ad
         * AcquistaPartiteGiaPrenoatate.jsp altrimenti il cliente non ha
         * prenotate la partite ed esegue l'else
         */
        HttpSession sess = request.getSession();
        Clienti cliente = (Clienti) sess.getAttribute("Login");
        DatiPartite partita = (DatiPartite) sess.getAttribute("PartitaSelezionata");

        String sql = "SELECT idpartita,squadra1,squadra2,stadio,ora,periodo,prezzo,pa.biglietti\n"
                + "                FROM prenotaacquista pa,dati d\n"
                + "                WHERE pa.PRENOTA = (?) and d.IDPARTITA = (?) and pa.IDCLIENTE = (?)and ora > CURRENT_TIME and periodo = CURRENT_DATE";

        try {
            prs = con.prepareStatement(sql);
            prs.setInt(1, partita.getId());
            prs.setInt(2, partita.getId());
            prs.setInt(3, cliente.getIdCliente());
            ResultSet rs = prs.executeQuery();

            while (rs.next()) {

                int idpartitaa = rs.getInt("idpartita");
                String squadra1 = rs.getString("squadra1");
                String squadra2 = rs.getString("squadra2");
                String stadio = rs.getString("stadio");
                Time ora = rs.getTime("ora");
                Date periodo = rs.getDate("periodo");
                int biglietti = rs.getInt("biglietti");
                double prezzo = rs.getDouble("prezzo");

                datiPartite = new DatiPartite(idpartitaa, squadra1, squadra2, stadio, prezzo, ora, periodo, 0, biglietti);
                clienteHaPrenotatoPartita = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AcquistaPartita.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (clienteHaPrenotatoPartita) {
            indirizzoPagina = "AcquistaPartiteGiaPrenotate.jsp";
             sess.setAttribute("PartitaInSessione", datiPartite);
        } else {
            indirizzoPagina = "AcquistaPartiteNonPrenotate.jsp";
        }
       
        RequestDispatcher di = request.getRequestDispatcher(indirizzoPagina);
        di.forward(request, response);

    }
}

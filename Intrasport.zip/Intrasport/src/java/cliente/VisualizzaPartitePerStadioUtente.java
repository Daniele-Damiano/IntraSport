/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Visualizza tutte le Partite in basa ad uno stadio i dati provengono da VisualizzaPartitaPerStadioUtente.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "VisualizzaPartitePerStadioUtente", urlPatterns = {"/VisualizzaPartitePerStadioUtente"})
public class VisualizzaPartitePerStadioUtente extends HttpServlet {

    private Connection con;
    private PreparedStatement prs;
    private ArrayList<DatiPartite> dati;
    private DatiPartite partite;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");
        try {
            /**
             * *
             * 1 Istruzione Driver Class 
             * 2 Istruzione Database Url Si trovano
             * nel tab service di netbeans nelle propieta sotto la cartella
             * Drivers
             */
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(VisualizzaPartitePerStadioUtente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        if (con != null) {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(VisualizzaPartitePerStadioUtente.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String stadio = request.getParameter("stadi");
        
        dati = new ArrayList<>();

        boolean elementoTrovato = false;
        String indirizzoPagina = "VisualizzaPartitaPerStadioUtente.jsp";

        String sql = "SELECT idpartita, squadra1, squadra2, stadio, prezzo, ora, periodo, biglietti \n"
                + "FROM DATI\n"
                + "WHERE ora > CURRENT_TIME and periodo = CURRENT_DATE and stadio = (?)";

        try {
            prs = con.prepareStatement(sql);
            prs.setString(1, stadio);
            ResultSet rs = prs.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("idpartita");
                String squadra1 = rs.getString("squadra1");
                String squadra2 = rs.getString("squadra2");
                String stadio1 = rs.getString("stadio");
                double prezzo = rs.getDouble("prezzo");
                Time ora = rs.getTime("ora");
                Date periodo = rs.getDate("periodo");
                int biglietti = rs.getInt("biglietti");

                partite = new DatiPartite(id, squadra1, squadra2, stadio1, prezzo, ora, periodo, 0, biglietti);
                dati.add(partite);

                elementoTrovato = true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaPartitePerStadioUtente.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (elementoTrovato) {
            request.setAttribute("partiteStadioTrovate", dati);

        } else {
            request.setAttribute("NessunaPartitaStadio", "Nessuna Partita Disponibile");
        }

        RequestDispatcher di = request.getRequestDispatcher(indirizzoPagina);
        di.forward(request, response);
    }

}

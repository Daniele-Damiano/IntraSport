/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logingestore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Esegue il Login del Gestore i dati provengono da Gestore.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "login", urlPatterns = {"/login"})
public class login extends HttpServlet {

    private Connection con;
    private Statement st;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {

            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);
        } catch (SQLException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, "Errore Connessione", ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, "Errore Class forname", ex);
        }

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        if (con != null) {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String ricorda = request.getParameter("RicordaUsername");

        String usr = null, pwd = null, indirizzoPagina = null;

        

       

        
        String sql = "SELECT username, password FROM LOGINGESTORE";
        
        try {
            if(username ==  "" && password == "")
                throw new NullPointerException();
            
            
            st = con.createStatement();
            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                usr = res.getString("username");
                pwd = res.getString("password");
            }
        } catch (SQLException | NullPointerException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
            
            indirizzoPagina = "Gestore.jsp";
            request.setAttribute("nonTrovato", "Utente Non Trovato");
        }

        if (username.equals(usr) && password.equals(pwd)) {

            indirizzoPagina = "DashboardGestore.html";

        } else {
            indirizzoPagina = "Gestore.jsp";
            request.setAttribute("nonTrovato", "Utente Non Trovato");
        }

        
        RequestDispatcher dis = request.getRequestDispatcher(indirizzoPagina);
        dis.forward(request, response);

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Visualizza Incasso Totale i dati provengono da Incasso.jsp
 * La servlet viene invocata da Incasso nell'url <a href = "Incasso
 * @author Daniele Damiano
 */
@WebServlet(name = "Incasso", urlPatterns = {"/Incasso"})
public class Incasso extends HttpServlet {

    private Connection conn;
    private PreparedStatement prs;
   

    /**
     * Apre una Connessione al database all'avvio della servlet Il metodo init
     * viene chiamato quando si avvia la servlet.
     *
     * @throws ServletException Se errori
     */
    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(InserimentoPartite.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Quando finisce il lavoro la servlet viene distrutta e con se anche la
     * connesione al database.
     */
    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Incasso.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

       /**
        * La funziona cast converte un tipo in un altro qui converte il valore di prezzo che e un double
        * in un numeric con precizione di 3 cifre prima della parte decimale e dopo il punto 3 cifre
        * e poi da un nome alla colonna che si chiama prezzo
        */
        String sql = "select sum(pa.PREZZOTOTALE) prezzo, sum(a.PREZZO)as prezzo1 from prenotaacquista pa, ACQUISTAPARTITASENZAACCEDERE a";
        double prezzo = 0;
        double prezzo1 = 0;

        try {

            prs = conn.prepareStatement(sql);

            ResultSet rs = prs.executeQuery();

            while (rs.next()) {
                prezzo = rs.getDouble("PREZZO");
                prezzo1 = rs.getDouble("prezzo1");
               
            }

        } catch (SQLException ex) {
            Logger.getLogger(Incasso.class.getName()).log(Level.SEVERE, null, ex);
        }
        double prezzoTotalee = prezzo+prezzo1;
        request.setAttribute("incassoTotale", prezzoTotalee);

        RequestDispatcher dis = request.getRequestDispatcher("incasso.jsp");
        dis.forward(request, response);
    }
}

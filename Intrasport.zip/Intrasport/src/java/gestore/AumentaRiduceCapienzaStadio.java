/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestore;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Aumenta e RIduce Capienza di uno Stadio i dati provengono da aumentariducecapienzastadio.jsp
 * @author Daniele Damiano
 */
@WebServlet(name = "AumentaRiduceCapienzaStadio", urlPatterns = {"/AumentaRiduceCapienzaStadio"})
public class AumentaRiduceCapienzaStadio extends HttpServlet {

    private Connection conn;
    private PreparedStatement prs;
    private double capienza;

    /**
     * Apre una Connessione al database all'avvio della servlet Il metodo init
     * viene chiamato quando si avvia la servlet.
     *
     * @throws ServletException Se errori
     */
    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AumentaRiduceCapienzaStadio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Quando finisce il lavoro la servlet viene distrutta e con se anche la
     * connesione al database.
     */
    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(AumentaRiduceCapienzaStadio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String stadio = request.getParameter("stadi");

        try {

            capienza = Double.valueOf(request.getParameter("capienza"));
            controllo(capienza);

            String sql = "UPDATE dati set capienza = (?) where stadio = (?)";
            prs = conn.prepareStatement(sql);
            prs.setDouble(1, capienza);
            prs.setString(2, stadio);
            prs.executeUpdate();

        } catch (NumberFormatException e) {
            Logger.getLogger(AumentaRiduceCapienzaStadio.class.getName()).log(Level.SEVERE, null, e);

            request.setAttribute("ErroreCapienza", "Formato Corretto [00.000], Non Superare 100.000 "
                    + "o immettere numeri negativi");
            RequestDispatcher dis = request.getRequestDispatcher("aumentariducecapienzastadio.jsp");
            dis.forward(request, response);

        } catch (IllegalArgumentException e) {
            Logger.getLogger(AumentaRiduceCapienzaStadio.class.getName()).log(Level.SEVERE, null, e);

            request.setAttribute("ErroreCapienza", "Formato Corretto [00.000], Non Superare 100.000 "
                    + "o immettere numeri negativi");
            RequestDispatcher dis = request.getRequestDispatcher("aumentariducecapienzastadio.jsp");
            dis.forward(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(AumentaRiduceCapienzaStadio.class.getName()).log(Level.SEVERE, null, ex);
        }

        RequestDispatcher dis = request.getRequestDispatcher("OperazioneEffettuataConSuccesso.jsp");
        dis.forward(request, response);

    }

    public void controllo(double capienza) throws IllegalArgumentException {
        if (capienza < 0) {
            throw new IllegalArgumentException();
        }
        if (capienza > 100.000) {
            throw new IllegalArgumentException();
        }
        if (capienza == 0) {
            throw new IllegalArgumentException();
        }
    }

}

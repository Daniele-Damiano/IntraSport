/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestore;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Visualizza tutte le partite in base ad uno specifico stadio
 * i dati provengono da VisualizzaPartiteStadio.jsp
 * @author Daniele Damiano
 */
@WebServlet(name = "VisualizzaPartiteStadio", urlPatterns = {"/VisualizzaPartiteStadio"})
public class VisualizzaPartiteStadio extends HttpServlet {

    private Connection conn;
    /**
     * Prepared Statement e usato per istruzione precompilate quando si devono
     * inserire valori e selezionare valori da input Statement Esegue
     * Unasemplice Istruzione SQL
     */
    private PreparedStatement prs;
    private ArrayList<DatiPartite> dati;
    private DatiPartite dp;

    /**
     * Apre una Connessione al database all'avvio della servlet Il metodo init
     * viene chiamato quando si avvia la servlet.
     *
     * @throws ServletException Se errori
     */
    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(VisualizzaPartiteStadio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Quando finisce il lavoro la servlet viene distrutta e con se anche la
     * connesione al database.
     */
    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaPartiteStadio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String stadi = request.getParameter("stadi");
       
        /**
         * Istanzia ArrayList
         */
        dati = new ArrayList<>();
        /**
         * Query al Database
         */
        String sql = "select * from dati where stadio = (?)";
        /**
         * Esecuzione Query prelievo dati dal database vengono messi in un Bean
         * DatiPartite il bean va nell arraylist prima istanziato cvengono
         * inviati aalla pagina jsp VisualizzaPartitaStadio e stampa i risultati
         * in una tabella
         */
        try {
            prs = conn.prepareStatement(sql);
            prs.setString(1, stadi);
            ResultSet rs = prs.executeQuery();

            while (rs.next()) {
                String sq1 = rs.getString("SQUADRA1");
                String sq2 = rs.getString("SQUADRA2");
                String stadio = rs.getString("STADIO");
                double prezzo = rs.getDouble("PREZZO");
                Time ora = rs.getTime("ORA");
                Date periodo = rs.getDate("PERIODO");
                double capienza = rs.getDouble("CAPIENZA");
                int biglietti = rs.getInt("BIGLIETTI");

                dp = new DatiPartite(0,sq1, sq2, stadio, prezzo, ora, periodo, capienza, biglietti);
                dati.add(dp);
            }
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaPartite.class.getName()).log(Level.SEVERE, null, ex);
        }

        request.setAttribute("partite", dati);

        RequestDispatcher dis = request.getRequestDispatcher("VisualizzaPartiteStadio.jsp");
        dis.forward(request, response);
    }
}

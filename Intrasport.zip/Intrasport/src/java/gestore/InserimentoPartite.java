/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Inserisce Partite nel database i dati provengono da InserisciPartita.jsp
 *
 * @author House
 */
@WebServlet(name = "InserimentoPartite", urlPatterns = {"/InserimentoPartite"})
public class InserimentoPartite extends HttpServlet {

    private Connection conn;
    /**
     * Prepared Statement e usato per istruzione precompilate quando si devono
     * inserire valori e selezionare valori da input Statement Esegue
     * Unasemplice Istruzione SQL
     */
    private PreparedStatement st;

    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(InserimentoPartite.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(InserimentoPartite.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        double prezzi = 0;
        int biglietti = 0;

        String squadra1 = request.getParameter("squadra1");
        String squadra2 = request.getParameter("squadra2");
        String stadio = request.getParameter("stadi");
        double capienza = Double.valueOf(request.getParameter("capienza"));
        String prezzo = request.getParameter("prezzo");
        String ora = request.getParameter("ora");
        String giorno = request.getParameter("giorno");
        String mese = request.getParameter("mese");
        String anno = request.getParameter("anno");
        String biglietto = request.getParameter("biglietti");

        /**
         * Converte la stringa ora e aggiunge :00 che sarebbero i secondi deve
         * esserci per forza il formato tipe on permette l'inserimento di dati
         * nel database se non ci sono i secondi
         *
         */
        Time time = Time.valueOf(ora + ":00");

        /**
         * Converte le stringhe anno mese e giorno nel formato Date i trattini
         * ci devono essere per forza per che e il formato in cui il databse
         * accettai dati e anche anno, mese, e giono deve stare cosi sempre per
         * il database che cosi accetta le Date
         *
         */
        Date date = Date.valueOf(anno + "-" + mese + "-" + giorno);

       

        /**
         * I valori ? nella stringa sql vengono settati da st.SETXXX dove gli
         * indici dono in ordine in base all'ordinamento delle colonne del
         * database e in base alla stringa sql 1 setta prima squadra1 2 setta
         * squadra2 3 setta stadio ec..
         */
        /**
         * Non Inserisce i dati nel database se l'input delcampo prezzo e
         * biglietto non e corretto Non esegue st.executeUpdate() che serve ad
         * inserire tutti i valori nel database.
         */
        /**
         * Se tutto L'inserimento nel database e avvenuto in modo corretto senza
         * errori visualizza una pagina di avvenuto inserimento con i dati
         * diriepilogo
         */
        String sql = "insert into dati(squadra1,squadra2,stadio,prezzo,ora,periodo,capienza,biglietti)"
                + " values(?,?,?,?,?,?,?,?)";
        try {
            
            prezzi = Double.valueOf(prezzo);
            biglietti = Integer.valueOf(biglietto);
            controllo(prezzi, biglietti);
            
            st = conn.prepareStatement(sql);
            
            st.setString(1, squadra1);
            st.setString(2, squadra2);
            st.setString(3, stadio);
            st.setTime(5, time);
            st.setDate(6, date);
            st.setDouble(7, capienza);
            st.setDouble(4, prezzi);
            st.setInt(8, biglietti);
            st.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(InserimentoPartite.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NumberFormatException e) {
            Logger.getLogger(InserimentoPartite.class.getName()).log(Level.SEVERE, null, e);

            request.setAttribute("inputNonValido", "Input non valido");
            RequestDispatcher disp = request.getRequestDispatcher("InserisciPartita.jsp");
            disp.forward(request, response);
        }

        request.setAttribute("squadra1", squadra1);
        request.setAttribute("squadra2", squadra2);
        request.setAttribute("stadio", stadio);
        request.setAttribute("capienza", capienza);
        request.setAttribute("prezzo", prezzi);
        request.setAttribute("ora", ora);
        request.setAttribute("periodo", anno + mese + giorno);
        request.setAttribute("biglietti", biglietti);

        RequestDispatcher di = request.getRequestDispatcher("InserimentoEffettuato.jsp");
        di.forward(request, response);

    }
    /**
     * 
     * @param prezzi Il prezzo di una parttia
     * @param biglietti I biglietti disponibili
     * @throws NumberFormatException Se in input non e corretto
     */
    public void controllo(double prezzi, int biglietti) throws NumberFormatException {
        if (prezzi < 0 || biglietti < 0) {
            throw new NumberFormatException();
        }
        if (prezzi > 10000) {
            throw new NumberFormatException();
        }
        if (prezzi == 0 || biglietti == 0) {
            throw new NumberFormatException();
        }
    }

}

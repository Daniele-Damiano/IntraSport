/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Assegna e Modifica Prezzo di una Partita i dati provengono da
 * assegnaprezzo.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "AssegnaModificaPrezzo", urlPatterns = {"/AssegnaModificaPrezzo"})
public class AssegnaModificaPrezzo extends HttpServlet {

    private Connection conn;
    private PreparedStatement prs;
    private double prezzo;

    /**
     * Apre una Connessione al database all'avvio della servlet Il metodo init
     * viene chiamato quando si avvia la servlet.
     *
     * @throws ServletException Se errori
     */
    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AssegnaModificaPrezzo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Quando finisce il lavoro la servlet viene distrutta e con se anche la
     * connesione al database.
     */
    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(AssegnaModificaPrezzo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String squadra1 = request.getParameter("squadra1");
        String squadra2 = request.getParameter("squadra2");
        String stadio = request.getParameter("stadi");
        String indirizzoPagina = "";
        boolean errore = false;

        String sql = "UPDATE dati set PREZZO = (?) where SQUADRA1 = (?) and SQUADRA2 = (?) and STADIO = (?)";

        try {
            prezzo = Double.valueOf(request.getParameter("prezzo"));
            controllo(prezzo);

            prs = conn.prepareStatement(sql);
            prs.setDouble(1, prezzo);
            prs.setString(2, squadra1);
            prs.setString(3, squadra2);
            prs.setString(4, stadio);
            prs.executeUpdate();

        } catch (SQLException | IllegalArgumentException ex) {
            Logger.getLogger(AssegnaModificaPrezzo.class.getName()).log(Level.SEVERE, null, ex);
            errore = true;

        }
        if (errore) {
            indirizzoPagina = "assegnaprezzo.jsp";
            request.setAttribute("ErroreFormato", "Il formato che hai inserito non e corretto <br> <strong>Formato [00.00] </strong>");
        } else {
            indirizzoPagina = "OperazioneEffettuataConSuccesso.jsp";
        }

        RequestDispatcher dis = request.getRequestDispatcher(indirizzoPagina);
        dis.forward(request, response);

    }

    /**
     * Controlla il prezzo se e minore di 0 o uguale a 0
     *
     * @param prezzo il prezzo che inserisce l'utente
     * @throws IllegalArgumentException se = 0 oppure <0
     */
    public void controllo(double prezzo) throws IllegalArgumentException {
        if (prezzo < 0) {
            throw new IllegalArgumentException();
        }
        if (prezzo == 0) {
            throw new IllegalArgumentException();
        }
    }
}

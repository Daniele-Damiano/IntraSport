/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestore;

import DatiPrelevatiDatabase.DatiPartite;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Visualizza Tutte le Partite la servlet genera la pagina Web per la visualizzazione dei dati
 * @author Daniele Damiano
 */
@WebServlet(name = "VisualizzaPartite", urlPatterns = {"/VisualizzaPartite"})
public class VisualizzaPartite extends HttpServlet {

    private Connection conn;
    /**
     * Prepared Statement e usato per istruzione precompilate quando si devono
     * inserire valori e selezionare valori da input Statement Esegue
     * Unasemplice Istruzione SQL
     */
    private Statement st;
    private ArrayList<DatiPartite> dati;

    
    
    /**
     * Apre una Connessione al database all'avvio della servlet
     * Il metodo init viene chiamato quando si avvia la servlet.
     * @throws ServletException Se errori
     */
    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(VisualizzaPartite.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    /**
     * Quando finisce il lavoro la servlet viene distrutta 
     * e con se anche la connesione al database.
     */
    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaPartite.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        /**
         * Istanzia ArrayList
         */
        dati = new ArrayList<>();
        /**
         * Query al Database
         */
        String sql = "select * from dati";
        /**
         * Esecuzione Query prelievo dati dal database
         * vengono messi in un Bean DatiPartite il bean va nell arraylist prima istanziato
         * crea una pagina dinamica html e stampa i risultati in una tabella
         */
        try {
            st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {
                int id = rs.getInt("idpartita");
                String sq1 = rs.getString("SQUADRA1");
                String sq2 = rs.getString("SQUADRA2");
                String stadio = rs.getString("STADIO");
                double prezzo = rs.getDouble("PREZZO");
                Time ora = rs.getTime("ORA");
                Date periodo = rs.getDate("PERIODO");
                double capienza = rs.getDouble("CAPIENZA");
               int biglietti = rs.getInt("BIGLIETTI");
                
                
                DatiPartite dp = new DatiPartite(id,sq1, sq2, stadio, prezzo, ora, periodo, capienza, biglietti);
                dati.add(dp);
            }
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaPartite.class.getName()).log(Level.SEVERE, null, ex);
        }
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>" + "<head>" + "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
        out.println("<title>VisualizzaPartite</title>" + " <link rel=\"stylesheet\" href=\"css/style.css\">");
        out.println("<style>");
        out.println(" table{"
                + "font-family: arial, sans-serif;\n"
                + "    border-collapse: collapse;\n"
                + "    width: 100%;\n"
                + "     font-size: 20px;"
                + "}" + "td, th {\n"
                + "    border: 1px solid #dddddd;\n"
                + "    text-align: left;\n"
                + "    padding: 8px;\n"
                + "}\n"
                + "\n"
                + "tr:nth-child(even) {\n"
                + "    background-color: #dddddd;\n"
                + "}"
        );
        out.println("</style");

        out.println(" </head>");
        out.println("<body>");
        out.println("<div id=\"header\">");
        out.println("<a href=\"index.html\"><img src=\"image/logo.png\" style=\"width:160px;height:85px;border:0;margin-top:-20px\"></a>");
        out.println("<div align=\"left\"><div style=\"width:300px; height: 10px; padding: 20px\"></div>");
        out.println("<h1>Partite</h1>"+"<br>");
        out.println("<table style=\"border: 1px solid black\">");
        out.println("<tr>"+"<th>Id Partita</th>" + "<th>Squadra</th>" + "<th> Squadra" + "</th>" + "<th>Stadio </th>"
                + "<th>Capienza</th>" + "<th>Prezzo</th>" + "<th>Ora</th>" + "<th>Periodo</th>" +"<th>Biglietti</th>"+ "</tr>");

        for (DatiPartite dp1 : dati) {
            out.println("<tr>");
            out.println("<td>" + "<a href=\"\">" + dp1.getId() + " </a>" + "</td>");
            out.println("<td>" + "<a href=\"\">" + dp1.getSquadra1() + " </a>" + "</td>");
            out.println("<td>" + "<a href=\"\">" + dp1.getSquadra2() + " </a>" + "</td>");
            out.println("<td>" + "<a href=\"\">" + dp1.getStadio() + " </a>" + "</td>");
            out.println("<td>" + "<a href=\"\">" + dp1.getCapienza()+ " </a>" + "</td>");
            out.println("<td>" + "<a href=\"\">" + dp1.getPrezzo()+ " </a>" + "</td>");
            out.println("<td>" + "<a href=\"\">" + dp1.getOra() + " </a>" + "</td>");
            out.println("<td>" + "<a href=\"\">" + dp1.getPeriodo() + " </a>" + "</td>");
             out.println("<td>" + "<a href=\"\">" + dp1.getBiglietti()+ " </a>" + "</td>");
            out.println("</tr>");
        }
        out.println("</table>" + "</body>" + "</html>");

    }
}

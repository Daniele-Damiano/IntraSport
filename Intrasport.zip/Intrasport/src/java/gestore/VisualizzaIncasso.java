/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestore;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Visualizza incasso in base allo stadio i dati provengono da Incasso.jsp
 *
 * @author Daniele Damiano
 */
@WebServlet(name = "VisualizzaIncasso", urlPatterns = {"/VisualizzaIncasso"})
public class VisualizzaIncasso extends HttpServlet {

    private Connection conn;
    private PreparedStatement prs;
    

    /**
     * Apre una Connessione al database all'avvio della servlet Il metodo init
     * viene chiamato quando si avvia la servlet.
     *
     * @throws ServletException Se errori
     */
    @Override
    public void init() throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.

        Properties pro = new Properties();
        pro.put("user", "admini");
        pro.put("password", "admini");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/DATIPARTITE", pro);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(VisualizzaIncasso.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Quando finisce il lavoro la servlet viene distrutta e con se anche la
     * connesione al database.
     */
    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.

        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaIncasso.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        /**
         * La funzione cast converte il tipo double che e memorizzato nel
         * database in numeric fa la somma di tutte le partite prendendo in
         * input uno stadio
         */
        String stadio = request.getParameter("stadi");

        double prezzo = 0;
        
        String sql = "SELECT sum(a.PREZZOTOTALE) as prezzoperstadio\n"
                + "FROM dati d, prenotaacquista a\n"
                + "WHERE a.ACQUISTA = d.IDPARTITA and d.STADIO = (?)";

        

        try {
            prs = conn.prepareStatement(sql);
            prs.setString(1, stadio);
            ResultSet rs = prs.executeQuery();

            while (rs.next()) {
                prezzo = rs.getDouble("prezzoperstadio");
               
            }

        } catch (SQLException ex) {
            Logger.getLogger(VisualizzaIncasso.class.getName()).log(Level.SEVERE, null, ex);
        }

        request.setAttribute("IncassoStadio", prezzo);

        RequestDispatcher dis = request.getRequestDispatcher("incasso.jsp");
        dis.forward(request, response);
    }

}

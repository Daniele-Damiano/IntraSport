/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prova;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author House
 */
public class select {
    public static void main(String[] arg) {
        String scrivi = null; 
        File f = new File("select.txt"); /**/
        if(!f.exists())
            try {
                f.createNewFile();
        } catch (IOException ex) {
            Logger.getLogger(select.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            FileWriter in = new FileWriter(f);
            for(int i = 1900; i < 2090; i++)
            {
                in.write("<option value ='"+i+"'>"+i+"</option>\n");
            }
            in.close();
        } catch (IOException ex) {
            Logger.getLogger(select.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatiPrelevatiDatabase;

import java.sql.Date;
import java.sql.Time;

/**
 * Contitne tutte le Partite che verranno prelevate dal database o memorizzate
 * @author Daniele Damiano
 */

public class DatiPartite {

    private int id;
    private String squadra1;
    private String squadra2;
    private String stadio;
    private double prezzo;
    private Time ora;
    private Date periodo;
    private double capienza;
    private int biglietti;
/**
 * 
 * @param id ID DELLA PARTITA
 * @param squadra1 SQUADRA CHE GIOCA
 * @param squadra2 SQUADRA CHE GIOCA
 * @param stadio STADIO DOVE SI DISPUTA LA PARTITA
 * @param prezzo PREZZO DELLA PARTITA
 * @param ora ORA D'INIZIO
 * @param periodo MESE GIORNO E ANNO IN CUI LA PARTITA SI GIOCA
 * @param capienza CAPIENZA DELLO STADIO
 * @param biglietti  BIGLIETTI DISPONIBILI PER LA PARTITA
 */
    public DatiPartite(int id, String squadra1, String squadra2, String stadio, double prezzo, Time ora, Date periodo, double capienza, int biglietti) {
        this.id = id;
        this.squadra1 = squadra1;
        this.squadra2 = squadra2;
        this.stadio = stadio;
        this.prezzo = prezzo;
        this.ora = ora;
        this.periodo = periodo;
        this.capienza = capienza;
        this.biglietti = biglietti;
    }
     

    public int getBiglietti() {
        return biglietti;
    }

    public void setBiglietti(int biglietti) {
        this.biglietti = biglietti;
    }

   

    public String getSquadra1() {
        return squadra1;
    }

    public void setSquadra1(String squadra1) {
        this.squadra1 = squadra1;
    }

    public String getSquadra2() {
        return squadra2;
    }

    public void setSquadra2(String squadra2) {
        this.squadra2 = squadra2;
    }

    public String getStadio() {
        return stadio;
    }

    public void setStadio(String stadio) {
        this.stadio = stadio;
    }

    public double getCapienza() {
        return capienza;
    }

    public void setCapienza(double capienza) {
        this.capienza = capienza;
    }

    public double getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(double prezzo) {
        this.prezzo = prezzo;
    }

    public Time getOra() {
        return ora;
    }

    public void setOra(Time ora) {
        this.ora = ora;
    }

    public Date getPeriodo() {
        return periodo;
    }

    public void setPeriodo(Date periodo) {
        this.periodo = periodo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

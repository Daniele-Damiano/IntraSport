/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatiPrelevatiDatabase;

import java.sql.Date;

/**
 * Contiene tutti i clienti che verranno inseriti nel database o prelevati dal databse
 *
 * @author Daniele Damiano
 */
public class Clienti {

    private int idCliente;
    private String nome;
    private String cognome;
    private Date dataNascita;
    private String username;
    private String password;
   

    /**
     * 
     * @param idCliente ID DEL CLIENTE
     * @param nome NOME DEL CLIENTE
     * @param cognome COGNOME DEL CLIENTE
     * @param dataNascita DATA DI NASCITA DEL CLIENTE
     * @param username USERNAME 
     * @param password PASSWORD
    */
  public Clienti(int idCliente, String nome, String cognome, Date dataNascita, String username, String password) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.cognome = cognome;
        this.dataNascita = dataNascita;
        this.username = username;
        this.password = password;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public Date getDataNascita() {
        return dataNascita;
    }

    public void setDataNascita(Date dataNascita) {
        this.dataNascita = dataNascita;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
